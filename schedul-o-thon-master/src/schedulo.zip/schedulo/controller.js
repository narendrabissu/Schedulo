const { parse } = require('querystring');
const express=require('express')
const jwt=require('jsonwebtoken');
const app=express();
const bodyParser = require("body-parser");
app.use(bodyParser.json());
//const User=require('D:/educational/schedulo/scheduloApp/src/app/user.js');
const pool=require('../../database');
const queries=require("./queries")
const getTrainee=(req,res)=>{
    pool.query(queries.getTrainee,(error,result)=>{
        if(error) throw error;
        res.status(200).json(result.rows);
    })
}
const getTraineeById=(req,res)=>{
    const id=parseInt(req.params.id);
    pool.query(queries.getTraineeById,[id],(error,result)=>{
        if(error) throw error;
        res.status(200).json(result.rows);
    })
}

const addTrainee=(req,res)=> {
    const {name,email,dob}=req.body;

    pool.query(queries.checkEmailExists,[email],(error,result)=>{
        if(result.rowCount){
            res.send("Account already exists with given email");
        }
        //add trainee to db
        pool.query(queries.addTrainee,[name,email,dob],(error,result)=>{
            if(error) throw error;
            res.status(201).send("Trainee added sucessfully!");
            console.log("Trainee created!")
        })
    })
}
const removeTrainee=(req,res)=>{
    const id=parseInt(req.params.id);
    pool.query(queries.getTraineeById,[id],(error,result)=>{
        const noTraineeFound=!result.rows.length;
        if(noTraineeFound){
            res.send("Trainee does not exists! Cant delete!");
        }
        pool.query(queries.removeTrainee,[id],(error,result)=>{
            if(error) throw error;
            res.status(200).send("Trainee removed suceesfully! ")
        })
    })
}
const updateTrainee=(req,res)=>{
    const id=parseInt(req.params.id);
    const {name}=req.body;
    pool.query(queries.getTraineeById,[id],(error,result)=>{
        const noTraineeFound=!result.rows.length;
        if(noTraineeFound){
            res.send("Trainee does not exists!");
        }
        pool.query(queries.updateTrainee,[name,id],(error,result)=>{
            if(error) throw error;
            res.status(200).send("Trainee updated suceesfully! ")

        })
    })


}
function verifyToken(req,res,next){
    if(!req.headers.authorization){
        res.status(401).send("unauthorized request")

    }
    let token=req.headers.authorization.split(' ')[1]
    if(token==='null'){
        res.status(401).send("unauthorized request")
    }
    let payload=jwt.verify(token, 'secretKey')
    if(!payload) res.status(401).send("unauthorized request")
    req.userId=payload.subject
    next()
}

const login=(req,res)=>{
    const {userid,password}=req.body;
    let role;
    //const password=parse(req.params.password);
    pool.query(queries.checkUserExists,[userid],(error,result)=>{
        const noUserExists=!result.rows.length;
        if(noUserExists){
            return res.status(401).send({msg:"Inavild userid"})
        }
        pool.query(queries.checkPassword,[userid,password],(error,result)=>{
            if(result.rowCount==0){
                return res.status(401).send({msg:"invalid Password"})
            }
            else{
                let payload={ subject: [userid]}
                let token=jwt.sign(payload,'secretKey')
                //console.log(result.rows[0].role);
                role=result.rows[0].role;
                return res.status(200).send({"token":token,"role":role});
                
            }
        })

    })
}

 const getScheduleById=(req,res)=>{
     const schedule_id=parseInt(req.params.schedule_id);
     pool.query(queries.getScheduleById,[schedule_id],(error,result)=>{
        if(error) throw error;
        res.status(200).json(result.rows);
    })
}
const getSchedules=(req,res)=>{
    pool.query(queries.getSchedules,(error,result)=>{
        if(error) throw error;
        res.status(200).json(result.rows);
    });
     
}
const addSchedules=(req,res)=>{
    const {schedule_name,description,batch,sub_batch,section}=req.body;
    
        pool.query(queries.addSchedules,[schedule_name,description,batch,sub_batch,section],(error,result)=>{
            if(error) throw error;
            return res.json({"msg":"schedule added sucessfully!"});
        })
}

const removeSchedule=(req,res)=>{
    const schedule_id=parseInt(req.params.schedule_id);
    console.log(schedule_id);
        pool.query(queries.removeSchedule,[schedule_id],(error,result)=>{
            if(error) throw error;
            return res.json({"msg":"Schedule removed suceesfully! "})
        })
    
}

const updateSchedule=(req,res)=>{
    const schedule_id=parseInt(req.params.schedule_id);
    console.log(schedule_id);
    const{schedule_name,description,batch,sub_batch,section}=req.body;
    pool.query(queries.updateSchedules,[schedule_name,description,batch,sub_batch,section,schedule_id],(error,result)=>{
        if(error) throw error;
        return res.json({"msg":"updated sucessfully"})
    }
    )
}

module.exports={
    getTrainee,
    getTraineeById,
    addTrainee,
    removeTrainee,
    updateTrainee,
    login,
    getSchedules,
    addSchedules,
    removeSchedule,
    updateSchedule,
    getScheduleById,

};