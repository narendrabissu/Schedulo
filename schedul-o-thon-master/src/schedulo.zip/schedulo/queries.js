const getTrainee="SELECT * FROM trainee";
const getTraineeById="Select * from trainee where id=$1";
const checkEmailExists="Select t from trainee t where t.email=$1";
const addTrainee="Insert into trainee (name,email,dob) values ($1,$2,$3)";
const removeTrainee="Delete from trainee where id=$1";
const updateTrainee="Update trainee set name=$1 where id=$2";
const checkUserExists="Select a from admin a where a.userid=$1";
const checkPassword="Select * from admin Where userid=$1 and password=$2";
const getScheduleById="Select * from schedules where schedule_id=$1";
const getSchedules="SELECT * FROM schedules";
const addSchedules="Insert into schedules (schedule_name,description,batch,sub_batch,section) values ($1,$2,$3,$4,$5)";
const removeSchedule="Delete from schedules where schedule_id=$1";
const updateSchedules="Update schedules set schedule_name=$1,description=$2,batch=$3,sub_batch=$4,section=$5 where schedule_id=$6";

module.exports={
    getTrainee,
    getTraineeById,
    checkEmailExists,
    addTrainee,
    removeTrainee,
    updateTrainee,
    checkUserExists,
    checkPassword,
    getSchedules,
    addSchedules,
    removeSchedule,
    updateSchedules,
    getScheduleById
};