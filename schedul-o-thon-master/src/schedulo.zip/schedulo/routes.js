const {Router}=require('express');
const controller=require('./controller');

const router=Router();
//router.get("/admin-view",controller.getTrainee);
//router.post("/",controller.addTrainee);
router.get("/:id",controller.getTraineeById);
//router.put("/:id",controller.updateTrainee);
//router.delete("/:id",controller.removeTrainee);
router.post("/login",controller.login);
//router.get("/getSchedules",controller.getSchedules);
router.post("/add_schedule",controller.addSchedules);
router.delete("/delete_schedule/:schedule_id",controller.removeSchedule);
router.get("/",controller.getSchedules);
router.put("/update_schedule/:schedule_id",controller.updateSchedule);
router.get("/getScheduleById/:schedule_id",controller.getScheduleById)
module.exports=router;